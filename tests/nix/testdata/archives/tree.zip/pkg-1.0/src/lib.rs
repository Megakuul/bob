pub fn f() -> u32 { 42 }
